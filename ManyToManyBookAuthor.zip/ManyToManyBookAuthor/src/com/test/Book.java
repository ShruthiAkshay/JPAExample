package com.test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="book_tbl")
public class Book {
	
	@Id
	@GeneratedValue
	private int ISBN;
	
	@Column(name="book_title",length=20)
	private String title;
	
	@Column(name="book_price",length=20)
	private String price;
	
	@OneToOne
	@JoinColumn(name="author_id")
	
	private Author author;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "author_books", joinColumns = { @JoinColumn(name = "author_id") }, inverseJoinColumns = { @JoinColumn(name = "ISBN") })
	private Set<Author> authors= new HashSet<>();	//required to avoid NullPointerException

	
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public Set<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

	public void addAuthor(Author author){
		this.getAuthors().add(author);
	}
	


}
