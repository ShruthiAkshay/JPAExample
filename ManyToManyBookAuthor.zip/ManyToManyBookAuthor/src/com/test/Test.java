package com.test;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hibernate.cfg.CreateKeySecondPass;

public class Test {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Book b = new Book();
		b.setTitle("Java");
		b.setPrice("500");
		
		Book b1= new Book();
		b1.setTitle("JavaCore");
		b1.setPrice("600");
		
		Author a=new Author();
		a.setName("BalaChandra");
		
		Author a1=new Author();
		a1.setName("kathy");

		b.addAuthor(a);
		b.addAuthor(a1);
		b1.addAuthor(a);
		b1.addAuthor(a1);
		
		em.persist(a);
		em.persist(a1);
		
		System.out.println("1:Select all books in database");
		System.out.println("2:Select all books written by given author name in database");
		System.out.println("3:List All books with given range");
		System.out.println("4:Select all author name for given bookid");
		System.out.println("5:exit");
		int choice = 0;
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		sc.nextLine();
		switch(choice)
		{
		case 1:
			  TypedQuery<Book> qrystr=em.createQuery("from Book",Book.class);   
				 List<Book> list = qrystr.getResultList();
				  
				  for(Book bk : list)
				  {
					   
					   System.out.println(bk.getISBN()+" "+bk.getTitle()+" "+bk.getPrice());
				  }
		}
		
		em.getTransaction().commit();
		System.out.println("added sucessfully");
		em.close();
		emf.close();
	}

}
	