package com.cg.author.client;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.author.bean.Author;
import com.cg.author.dao.IAuthorDAO;
import com.cg.author.exception.AuthorException;
import com.cg.author.service.AuthorServiceImpl;
import com.cg.author.service.IAuthorService;

public class Client {

	public static void main(String[] args){

		Author author = new Author();
		Scanner sc= new Scanner(System.in);
		IAuthorService ser= new AuthorServiceImpl();
		
		System.out.println("1.Add Author");
		System.out.println("2.Delete Author");
		System.out.println("3.Find Author");
		System.out.println("4.Display All Author");
		System.out.println("5.Exit");
		System.out.println("Enter Your Choice: ");
		
		int choice=sc.nextInt();
		
		switch(choice){
		case 1:
		System.out.println("Enter author First Name:");
		String firstName=sc.nextLine();
		author.setFirstName(firstName);
		System.out.println("Enter author Middle Name:");
		String middleName=sc.nextLine();
		author.setMiddleName(middleName);
		System.out.println("Enter author Last Name:");
		String lastName=sc.nextLine();
		author.setLastName(lastName);
		System.out.println("Enter author Phone Number:");
		String phoneNumber=sc.nextLine();
		author.setPhoneNumber(phoneNumber);
		
		try {
			int id=ser.addDetails(author);
			System.out.println("Author added to database successfully and authorId is:"+id);
		} catch (AuthorException e) {
			e.printStackTrace();
		}
		break;
		case 2:
			System.out.println("Enter author Id of author to be deleted:");
			try {
				int authorId=sc.nextInt();
				boolean status=ser.delete(authorId);
				if(status==false)
				{
					System.out.println("Couldn't delete author!!");
				}else{
					System.out.println("Author deleted successfully whose author ID is: "+authorId);
				}
			} catch (AuthorException e) {
				
				e.printStackTrace();
			}
			break;
		}
	}

}
