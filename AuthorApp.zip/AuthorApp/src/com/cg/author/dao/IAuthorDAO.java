package com.cg.author.dao;

import java.util.List;

import com.cg.author.bean.Author;
import com.cg.author.exception.AuthorException;

public interface IAuthorDAO {
	public int addDetails(Author author)throws AuthorException;
	
	public boolean delete(int authorId)throws AuthorException;
	
	/*public boolean search(int authorId)throws AuthorException;
	
	public List<Author> getAllAuthors()throws AuthorException;*/

	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
