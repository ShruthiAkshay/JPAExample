package com.cg.author.dao;



import javax.persistence.EntityManager;


import com.cg.author.bean.Author;
import com.cg.author.exception.AuthorException;

public class AuthorDAOImpl implements IAuthorDAO {
	Author author=new Author();
	private EntityManager entityManager;

	public AuthorDAOImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public int addDetails(Author author) throws AuthorException {
	
		entityManager.getTransaction().begin();
		entityManager.persist(author);
		
		entityManager.getTransaction().commit();
		
		return author.getAuthorId();
	}

	@Override
	public boolean delete(int authorId) throws AuthorException {
		entityManager.getTransaction().begin();
		
		Author aut=entityManager.find(Author.class, authorId);
		if(aut==null)
		{
			return false;
		}
		else{
			entityManager.remove(aut);
			entityManager.getTransaction().commit();
			return true;
		}
		
	}
/*
	@Override
	public boolean search(int authorId) throws AuthorException {
		Author auth=entityManager.find(Author.class, authorId);
		if(auth==null)
		{
			return false;
		}else{
			return true;
		}
	}

	@Override
	public List<Author> getAllAuthors() throws AuthorException {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
			Employee emp=em.find(Employee.class, 3);
			if(emp==null)
			{
				System.out.println("Employee not found");
			}
			else{
				System.out.println(emp.getEmployeeName()+" "+emp.getEmployeeSalary());
			}
			em.getTransaction().commit();
			System.out.println("employee added to database");
			em.close();
			emf.close();
	}*/

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().commit();

	}

}
