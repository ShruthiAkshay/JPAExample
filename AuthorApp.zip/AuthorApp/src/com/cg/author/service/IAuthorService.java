package com.cg.author.service;

import com.cg.author.bean.Author;
import com.cg.author.exception.AuthorException;

public interface IAuthorService {
	public int addDetails(Author author)throws AuthorException;
	public boolean delete(int authorId)throws AuthorException;
	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
