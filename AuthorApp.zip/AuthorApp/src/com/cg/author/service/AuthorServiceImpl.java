package com.cg.author.service;

import javax.persistence.EntityManager;

import com.cg.author.bean.Author;
import com.cg.author.dao.AuthorDAOImpl;
import com.cg.author.dao.IAuthorDAO;
import com.cg.author.exception.AuthorException;


public class AuthorServiceImpl implements IAuthorService {
	Author author = new Author();
	private IAuthorDAO dao;
	private EntityManager entityManager;
	public AuthorServiceImpl() {
		dao = new AuthorDAOImpl();
	}
	@Override
	public int addDetails(Author author) throws AuthorException {
	int id=	dao.addDetails(author);
		return id;
	}
	@Override
	public boolean delete(int authorId) throws AuthorException {
		boolean flag=dao.delete(authorId);
		return flag;
	}
	
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().commit();

	}

}
